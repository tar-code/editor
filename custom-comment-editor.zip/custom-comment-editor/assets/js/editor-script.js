jQuery(document).ready(function($) {
    // Обработка кнопок редактора
    $('.editor-btn').click(function() {
        var command = $(this).data('command');
        var textarea = $('#comment')[0];  // Получаем элемент textarea
        if (!textarea) return;  // Проверка на существование элемента

        var text = textarea.value;
        var start = textarea.selectionStart;
        var end = textarea.selectionEnd;
        var selectedText = text.substring(start, end);
        var beforeText = text.substring(0, start);
        var afterText = text.substring(end, text.length);

        switch(command) {
            case 'bold':
                textarea.value = beforeText + '<b>' + selectedText + '</b>' + afterText;
                break;
            case 'code':
                textarea.value = beforeText + '<code>' + selectedText + '</code>' + afterText;
                break;
            case 'link':
                var url = prompt("Введите URL", "http://");
                if (url) {
                    textarea.value = beforeText + '<a href="' + url + '">' + selectedText + '</a>' + afterText;
                }
                break;
            case 'image':
                var imageUrl = prompt("Введите URL изображения", "http://");
                if (imageUrl) {
                    textarea.value = beforeText + '<img src="' + imageUrl + '" alt="Image">' + afterText;
                }
                break;
            case 'list':
                // Формируем правильный список
                var listItems = selectedText.split('\n').map(function(item) {
                    return '<li>' + item + '</li>';
                }).join('');
                textarea.value = beforeText + '<ul>' + listItems + '</ul>' + afterText;
                break;
            case 'pre':
                textarea.value = beforeText + '<pre>' + selectedText + '</pre>' + afterText;
                break;
            case 'emoji':
                // Показываем или скрываем окно выбора смайлов
                $('#emoji-picker').toggle();
                break;
            case 'preview': // Обработка кнопки предпросмотра
                var previewDiv = $('#comment-preview');
                if (previewDiv.is(':visible')) {
                    previewDiv.hide();
                } else {
                    var commentContent = $('#comment').val();
                    previewDiv.html(commentContent);
                    previewDiv.show();
                }
                break;
        }

        textarea.focus();
    });

    // Обработка кликов на смайлы
    $('#emoji-picker').on('click', '.emoji', function() {
        var emoji = $(this).attr('alt');
        var emojiMap = {
            'Smile': '😊',
            'Wink': '😉',
            'Thumbs Up': '👍',
            'Ok Hand': '👌',
            'Waving Hand': '👋',
            'Zany Face': '🤪',
            'Clapping Hands': '👏',
            'Heart': '❤️',
            'Joy': '😂'
            // Добавьте больше смайлов и их коды
        };
        var emojiChar = emojiMap[emoji] || emoji;
        var textarea = $('#comment')[0];
        if (!textarea) return;

        var text = textarea.value;
        var start = textarea.selectionStart;
        var end = textarea.selectionEnd;
        var beforeText = text.substring(0, start);
        var afterText = text.substring(end, text.length);

        // Вставляем смайлик в текстовое поле
        textarea.value = beforeText + emojiChar + afterText;

        // Обновляем курсор после вставки текста
        textarea.selectionStart = textarea.selectionEnd = beforeText.length + emojiChar.length;
        textarea.focus();

        // Скрываем окно выбора смайлов
        $('#emoji-picker').hide();
    });
});