<?php
/*
Plugin Name: Custom Comment Editor
Description: A comment plugin with a text editor for WordPress.
Plugin URI: https://github.com/tar-code/Custom-Comment-Editor-WordPress
Version: 1.0
Author: LearnClub
Author URI: https://learnclub.uk
*/

function enqueue_custom_comment_editor_scripts() {
    wp_enqueue_style('custom-comment-editor-css', plugin_dir_url(__FILE__) . 'assets/css/editor-style.css');
    wp_enqueue_script('custom-comment-editor-js', plugin_dir_url(__FILE__) . 'assets/js/editor-script.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'enqueue_custom_comment_editor_scripts');

// Замена стандартного поля комментария на кастомное
function custom_replace_comment_field($fields) {
    // Убираем стандартное поле комментария
    unset($fields['comment']);

    // Получаем URL к папке плагина
    $plugin_dir_url = plugins_url('custom-comment-editor/image/');

    // Добавляем кастомное поле
    $fields['comment'] = '<div class="custom-editor">
        <div class="editor-toolbar">
            <button type="button" class="editor-btn" data-command="bold">
                <img src="' . $plugin_dir_url . 'b.svg" alt="Bold">
            </button>
            <button type="button" class="editor-btn" data-command="code">
                <img src="' . $plugin_dir_url . 'code.svg" alt="Code">
            </button>
            <button type="button" class="editor-btn" data-command="link">
                <img src="' . $plugin_dir_url . 'link.svg" alt="Link">
            </button>
            <button type="button" class="editor-btn" data-command="image">
                <img src="' . $plugin_dir_url . 'image.svg" alt="Image">
            </button>
            <button type="button" class="editor-btn" data-command="list">
                <img src="' . $plugin_dir_url . 'list.svg" alt="List">
            </button>
            <button type="button" class="editor-btn" data-command="pre">
                <img src="' . $plugin_dir_url . 'pre.svg" alt="Pre">
            </button>
            <button type="button" class="editor-btn" data-command="emoji" id="emoji-btn">
                <img src="' . $plugin_dir_url . 'emoji.svg" alt="Emoji">
            </button>
            <button type="button" class="editor-btn" data-command="preview" id="preview-btn">
                <img src="' . $plugin_dir_url . 'preview.svg" alt="Preview">
            </button>
        </div>
        <textarea id="comment" name="comment" class="custom-textarea"></textarea>
        <div id="emoji-picker" class="emoji-picker" style="display:none;">
            <!-- Добавьте список смайлов, каждый смайл это картинка -->
            <img src="' . $plugin_dir_url . 'smile.svg" class="emoji" alt="Smile">
            <img src="' . $plugin_dir_url . 'wink.svg" class="emoji" alt="Wink">
            <img src="' . $plugin_dir_url . 'thumbs-up.svg" class="emoji" alt="Thumbs Up">
            <img src="' . $plugin_dir_url . 'ok-hand.svg" class="emoji" alt="Ok Hand">
            <img src="' . $plugin_dir_url . 'waving-hand.svg" class="emoji" alt="Waving Hand">
            <img src="' . $plugin_dir_url . 'zany-face.svg" class="emoji" alt="Zany Face">
            <img src="' . $plugin_dir_url . 'clapping-hands.svg" class="emoji" alt="Clapping Hands">
            <img src="' . $plugin_dir_url . 'heart.svg" class="emoji" alt="Heart">
            <img src="' . $plugin_dir_url . 'joy.svg" class="emoji" alt="Joy">
            <!-- Добавьте больше смайлов по вашему усмотрению -->
        </div>
        <div id="comment-preview" style="display:none;"></div>
    </div>';

    return $fields;
}
add_filter('comment_form_fields', 'custom_replace_comment_field');
?>